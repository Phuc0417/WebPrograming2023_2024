package vn.iotstar.utils;

public class Constant {
	public static final String SESSION_USERNAME = "username";
	public static final String COOKIE_REMEMBER = "username";
	public static final String DIR = "D:\\uploads";

	public static class Path {
		public static final String LOGIN = "login.jsp";
		public static final String REGISTER = "register.jsp";

	}

}
